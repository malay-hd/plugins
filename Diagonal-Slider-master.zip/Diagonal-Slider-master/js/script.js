$(document).ready(function(){
	$('.gallery_content').createDiagonalSlider();
});