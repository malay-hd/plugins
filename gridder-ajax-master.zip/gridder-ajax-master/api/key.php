<?php
// League of Legends API KEY
// You can register for an api developer key at : https://developer.riotgames.com/
$key = 'XXXXXX-XXXXXX-XXXXXX-XXXXXX-XXXXXX';
