Clipped SVG Slider
=========

A simple slider, with morphing preview images animated using SVG properties.

[Article on CodyHouse](https://codyhouse.co/gem/clipped-svg-slider/)

[Demo](https://codyhouse.co/demo/clipped-svg-slider/diamond.html)
 
[Terms](https://codyhouse.co/terms/)

Resources:

-[Snap.svg](http://snapsvg.io/) to animate the SVG elements.

-Images from [Unsplash](https://unsplash.com/)